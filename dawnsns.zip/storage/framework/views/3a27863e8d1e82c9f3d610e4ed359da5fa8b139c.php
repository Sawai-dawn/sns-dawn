

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">

  <div class='container'>
    <h1 class='page-header'></h1>
    <div class="profile">
      <div class="profile-header">
      <img src="<?php echo e($user->icon_image ? asset('storage/' . $user->icon_image) : asset('images/dawn.png')); ?>" alt="プロフィール画像" class="rounded-circle" style="height: 60px;">
      </div>

      <div class="profile-info">
        <div class="profile-item">
          <span class="label">UserName</span>
          <span class="value"><?php echo e(Auth::user()->name); ?></span>
        </div>
        <div class="profile-item">
          <span class="label">MailAddress</span>
          <span class="value"><?php echo e(Auth::user()->email); ?></span>
        </div>
        <div class="profile-item">
          <span class="label">BIO</span>
          <span class="value"><?php echo e(Auth::user()->bio); ?></span>
        </div>
        <div class="profile-item">
          <a type="submit" class="btn btn-update" href="<?php echo e(route('updateProfile')); ?>">変更画面へ</a>
        </div>
      </div>
    </div>

    <div class="div-line"></div>

    <h2 class='page-header'></h2>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <div class="post-card">
        <div class="post-header">
          <?php if(auth()->id() === $post->user_id): ?>
            <a href="<?php echo e(route('myProfile')); ?>">
              <img src="<?php echo e($post->user->icon_image ? asset('storage/' . $post->user->icon_image) : asset('images/dawn.png')); ?>" alt="プロフィール画像" class="user-icon">
            </a>

          <?php else: ?>
            <a href="<?php echo e(route('users.profile', ['id' => $post->user_id])); ?>">
              <img src="<?php echo e($post->user->icon_image ? asset('storage/' . $post->user->icon_image) : asset('images/dawn.png')); ?>" alt="プロフィール画像" class="user-icon">
            </a>

          <?php endif; ?>

          <div class="post-meta">
            <span class="post-user"><?php echo e($post->user->name); ?></span>
            <span class="post-date"><?php echo e($post->created_at->format('Y-m-d H:i')); ?></span>
          </div>
        </div>

        <div class="post-content">
          <?php echo nl2br(e($post->post)); ?>

        </div>

        <div class="post-actions">
          <?php if(auth()->id() === $post->user_id): ?> <!-- ログインユーザーの投稿だけ表示 -->
            <a class="btn btn-primary" href="/post/<?php echo e($post->id); ?>/update-form"></a>
          <?php endif; ?>

          <!-- ↑　ここまで追加してください -->
          <!-- ↓　ここから下を追加してください -->
          <?php if(auth()->id() === $post->user_id): ?> <!-- ログインユーザーの投稿だけ削除ボタンを表示 -->
            <form action="/post/delete" method="post" onclick="return confirm('この呟きを削除します。よろしいでしょうか？')">
              <?php echo method_field('DELETE'); ?>
              <?php echo csrf_field(); ?>
              <input type="hidden" name="id" value="<?php echo e($post->id); ?>">
              <button type="submit" class="btn btn-danger"></button>
            </form>
          <?php endif; ?>
          <!-- ↑　ここまでを追加してください -->
        </div>

        <div class="div-line2"></div>

      </div>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/posts/myProfile.blade.php ENDPATH**/ ?>