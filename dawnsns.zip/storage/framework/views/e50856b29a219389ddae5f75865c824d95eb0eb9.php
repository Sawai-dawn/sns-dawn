

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">

  <h2 style="color: #6c6c6c;">Follow list</h2>
  <div class='container'>


    <div class="user-icon-list">
      <?php $__empty_1 = true; $__currentLoopData = $followings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $followed): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <a href="<?php echo e(route('users.profile', ['id' => $followed->id])); ?>">
          <img src="<?php echo e($followed->icon_image ? asset('storage/' . $followed->icon_image) : asset('images/dawn.png')); ?>" alt="プロフィール画像" class="user-icon">
        </a>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>フォローしているユーザーはいません。</p>

      <?php endif; ?>
    </div>

    <div class="div-line"></div>

    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="post-card">
      <div class="post-header">
      <?php if(auth()->id() === $post->user_id): ?>
        <a href="<?php echo e(route('myProfile')); ?>">
          <img src="<?php echo e($post->user->icon_image ? asset('storage/' . $post->user->icon_image) : asset('images/dawn.png')); ?>" alt="プロフィール画像" class="user-icon">
        </a>

      <?php else: ?>
        <a href="<?php echo e(route('users.profile', ['id' => $post->user_id])); ?>">
          <img src="<?php echo e($post->user->icon_image ? asset('storage/' . $post->user->icon_image) : asset('images/dawn.png')); ?>" alt="プロフィール画像" class="user-icon">
        </a>

      <?php endif; ?>

        <div class="post-meta">
          <span class="post-user"><?php echo e($post->user->name); ?></span>
          <span class="post-date"><?php echo e($post->created_at->format('Y-m-d H:i')); ?></span>
        </div>
      </div>

      <div class="post-content">
        <?php echo nl2br(e($post->post)); ?>

      </div>

      <div class="post-actions">
        <?php if(auth()->id() === $post->user_id): ?> <!-- ログインユーザーの投稿だけ表示 -->
          <a class="btn btn-primary" href="/post/<?php echo e($post->id); ?>/update-form"></a>

        <?php endif; ?>

        <?php if(auth()->id() === $post->user_id): ?> <!-- ログインユーザーの投稿だけ削除ボタンを表示 -->
          <form action="/post/delete" method="post" onclick="return confirm('この呟きを削除します。よろしいでしょうか？')">
            <?php echo method_field('DELETE'); ?>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" value="<?php echo e($post->id); ?>">
            <button type="submit" class="btn btn-danger"></button>
          </form>

        <?php endif; ?>

      </div>

      <div class="div-line2"></div>

    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/users/followList.blade.php ENDPATH**/ ?>