

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">

  <div class='container'>
    <form action="/post/update/" method="post">
      <?php echo method_field('PUT'); ?>
      <?php echo csrf_field(); ?>
      <div class="form-group">
      <img src="<?php echo e($user->icon_image ? asset('storage/' . $user->icon_image) : asset('images/dawn.png')); ?>" alt="プロフィール画像" class="rounded-circle" style="height: 60px;">
        <input type="hidden" name="id" value="<?php echo e($post->id); ?>">
        <textarea name="upPost" class="form-control" required rows="8"><?php echo e(old('upPost', $post->post)); ?></textarea>
      </div>
      <div class="pull-right submit-btn">
        <button type="submit" class="btn btn-primary"></button>
      </div>
    </form>
  </div>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/posts/updateForm.blade.php ENDPATH**/ ?>