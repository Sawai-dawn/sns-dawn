<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
<div class="container">
    <div class="row justify-content-center text-center">
    <div class="md-8 text-center">
        <img src="<?php echo e(asset('images/main_logo.png')); ?>" alt="ロゴ画像" class="LoginLogoImage">
        <label for="LoginText" class="col-form-label d-block" style="color: #FFFFFF; font-size: 45px; margin-bottom: 60px;"><?php echo e(__('Social Network Service')); ?></label>
    </div>

    <div class="col-md-4">
        <div class="card">
                <div class="card-header"><?php echo e(__('DAWNのSNSへようこそ')); ?></div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="mb-3 text-center">
                            <div class="mx-auto" style="max-width: 300px; text-align: left;">
                                <label for="email" class="col-form-label text-start d-block"><?php echo e(__('MailAddress')); ?></label>
                                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value=" <?php echo e(old('email')); ?>" required autocomplete="email">
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback d-block" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="mb-3 text-center">
                            <div class="mx-auto" style="max-width: 300px; text-align: left;">
                                <label for="password" class="col-form-label text-start d-block"><?php echo e(__('Password')); ?></label>
                                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="new-password">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback d-block" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="mb-0 text-center">
                            <div class="col-md-8 offset-md-5">
                                <button type="submit" class="btn btn-login">
                                    <?php echo e(__('ＬＯＧＩＮ')); ?>

                                </button>
                            </div>

                                <?php if(Route::has('register')): ?>
                                    <a class="btn btn-link" href="<?php echo e(route('register')); ?>">
                                        <?php echo e(__('新規ユーザーの方はこちら')); ?>

                                    </a>
                                <?php endif; ?>

                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/auth/login.blade.php ENDPATH**/ ?>