<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

</head>
<body class="<?php echo e(Route::currentRouteName()); ?>">
    <div id="app">
    <?php if(!in_array(Route::currentRouteName(), ['login', 'register'])): ?>
        <nav class="navbar navbar-expand-md navbar-light shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(url('/index')); ?>">
                    <img src="<?php echo e(asset('images/main_logo.png')); ?>" alt="ロゴ" style="height: 60px;">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav me-auto">

                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ms-auto">
                        <!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(Route::has('login')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                                </li>
                            <?php endif; ?>

                            <?php if(Route::has('register')): ?>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    <?php echo e(Auth::user()->name); ?> さん
                                    <span class="dropdown-line"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                    <a class="dropdown-item" href="<?php echo e(url('/index')); ?>"> <?php echo e(__('HOME')); ?>

                                    </a>

                                    <a class="dropdown-item" href="<?php echo e(route('myProfile')); ?>"> <?php echo e(__('プロフィール編集画面')); ?>

                                    </a>

                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('ログアウト')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                            <img src="<?php echo e(Auth::user()->icon_image ? asset('storage/' . Auth::user()->icon_image) : asset('images/dawn.png')); ?>" alt="プロフィール画像" class="rounded-circle" style="height: 30px;">
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>
        <?php endif; ?>

        <?php if(!in_array(Route::currentRouteName(), ['login', 'register'])): ?>
        <main class="layout-container">
            <div class="content py-4">
                <?php echo $__env->yieldContent('content'); ?>
            </div>


            <aside class="sidebar">
                <a><?php echo e(Auth::user()->name); ?>さんの</a>
                <div class="follow-num">
                   <span class="left">フォロー数</span>
                   <span class="right"><?php echo e(Auth::user()->followings->count()); ?>名</span>
                </div>
                <a class="btn btn-followlist" href="<?php echo e(route('followList')); ?>">
                    <?php echo e(__('フォローリスト')); ?>

                </a>

                <div class="follow-num">
                   <span class="left">フォロワー数</span>
                   <span class="right"><?php echo e(Auth::user()->followers->count()); ?>名</span>
                </div>
                <a class="btn btn-followlist" href="<?php echo e(route('followerList')); ?>">
                    <?php echo e(__('フォロワーリスト')); ?>

                </a>

                <hr>
                <div>
                <a class="btn btn-usersearch" href="<?php echo e(route('usersSearch')); ?>">
                    <?php echo e(__('ユーザー検索')); ?>

                </a>
                </div>
            </aside>
        </main>

        <?php else: ?>
        <main class="top-container">
            <div class="content py-4">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </main>
        <?php endif; ?>
    </div>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/layouts/app.blade.php ENDPATH**/ ?>