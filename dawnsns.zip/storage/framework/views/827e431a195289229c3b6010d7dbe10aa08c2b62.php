

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">

  <div class='container'>
    <h1 class='page-header'>Laravelを使った投稿機能の実装</h1>
    <h2 class='page-header'>新しく投稿をする</h2>
    <form action="/post/create" method="post">
      <?php echo csrf_field(); ?>
      <div class="form-group">
        <input type="text" name="newPost" class="form-control" placeholder="投稿内容">
      </div>
      <div class="pull-right submit-btn">
        <button type="submit" class="btn btn-success">追加</button>
      </div>
    </form>
  </div>

  <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/posts/createForm.blade.php ENDPATH**/ ?>