

<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">

  <div class='container'>
    <div class="search-wrap">
      <form method="GET" action="<?php echo e(route('usersSearch')); ?>" class="search-form">
        <input type="text" name="keyword" value="<?php echo e(request('keyword')); ?>" class="value form-control" placeholder="ユーザー名">
        <button type="submit" class="btn btn-search"></button>
      </form>

      <?php if(request('keyword')): ?>
        <div class="search-keyword">検索ワード：<?php echo e(request('keyword')); ?></div>
      <?php endif; ?>
    </div>

    <div class="div-line"></div>


    <div class="all-users">
      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="user-row">
          <a href="<?php echo e(route('users.profile', ['id' => $user->id])); ?>">
            <img src="<?php echo e($user->icon_image ? asset('storage/' . $user->icon_image) : asset('images/dawn.png')); ?>" alt="プロフィール画像" class="user-icon">
          </a>
          <span class="value username"><?php echo e($user->name); ?></span>

        <?php if(Auth::user()->followings->contains($user->id)): ?>
        <!-- ログインユーザーがこのユーザーをフォロー済みなら -->

          <form action="<?php echo e(route('unfollow', ['id' => $user->id])); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <button type="submit" class="btn btn-unfollow">フォローをはずす</button>
          </form>

        <?php else: ?>
        <!-- フォローしていない場合 -->

          <form action="<?php echo e(route('follow', ['id' => $user->id])); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <button type="submit" class="btn btn-follow">フォローする</button>
          </form>

        <?php endif; ?>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

  </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/users/usersSearch.blade.php ENDPATH**/ ?>